# Simple blockchain

An exercise to help individuals understand the basics of blockchain.

### The Exercise

The exercise - download the codebase and get the tests to pass!

- Start with the hash implementation (previousHash + timestamp + nonce).
- Move to isEmpty and Size.
- Ensure the negative tests pass!

Hope you enjoy the exercise!

Thanks, @barinek

© 2022 by Continuum Collective, Inc. All rights reserved.
